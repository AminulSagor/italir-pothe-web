const TTS_API_URL = process.env.NEXT_PUBLIC_TTS_API_URL;

export const generateLocalTtsAudio = async (text: string): Promise<File> => {
  const normalizedText = text.trim();

  if (!normalizedText) {
    throw new Error("Text is required to generate audio.");
  }

  if (!TTS_API_URL) {
    throw new Error("NEXT_PUBLIC_TTS_API_URL is not configured.");
  }

  const response = await fetch(TTS_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      text: normalizedText,
    }),
  });

  if (!response.ok) {
    throw new Error("Unable to generate audio.");
  }

  const blob = await response.blob();

  if (!blob.size) {
    throw new Error("Generated audio is empty.");
  }

  return new File([blob], `quiz-tts-${Date.now()}.wav`, {
    type: "audio/wav",
  });
};
